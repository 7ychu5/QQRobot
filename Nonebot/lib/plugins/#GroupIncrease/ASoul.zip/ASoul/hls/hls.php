<?php
$path = './hls';
if (is_dir($path)) {
    $fileArray = scandir($path, 1);
    $imageUrl = "http://119.91.206.68/wp-content/uploads/hls/" . $fileArray[mt_rand(0, sizeof($fileArray) - 2)];
    header("Location: $imageUrl");
}
